import themeReducer from './themeReducer';
import sidebarReducer from './sidebarReducer';

export {
  themeReducer,
  sidebarReducer
}